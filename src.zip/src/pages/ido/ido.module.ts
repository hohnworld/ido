import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IdoPage } from './ido';

@NgModule({
  declarations: [
    IdoPage,
  ],
  imports: [
    IonicPageModule.forChild(IdoPage),
  ],
})
export class IdoPageModule {}
