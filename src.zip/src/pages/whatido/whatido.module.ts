import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WhatidoPage } from './whatido';

@NgModule({
  declarations: [
    WhatidoPage,
  ],
  imports: [
    IonicPageModule.forChild(WhatidoPage),
  ],
})
export class WhatidoPageModule {}
