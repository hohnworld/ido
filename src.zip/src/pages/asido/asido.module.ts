import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AsidoPage } from './asido';

@NgModule({
  declarations: [
    AsidoPage,
  ],
  imports: [
    IonicPageModule.forChild(AsidoPage),
  ],
})
export class AsidoPageModule {}
