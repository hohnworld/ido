import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IdoforPage } from './idofor';

@NgModule({
  declarations: [
    IdoforPage,
  ],
  imports: [
    IonicPageModule.forChild(IdoforPage),
  ],
})
export class IdoforPageModule {}
